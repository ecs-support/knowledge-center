---
title: ข้อมูลทางวิชาการ
bookCollapseSection: true
weight: 1
bookToc: false
---


ข้อมูลทางวิชาการ
===



[พระราชบัญญัติศุลกากร พ.ศ. 2560 (คำแปลภาษาอังกฤษ) CUSTOMS ACT B.E. 2560 (2017)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3-e0b89e-e0b8a8.pdf)

[คำศัพท์ภาษาอังกฤษตามพระราชบัญญัติศุลกากร 2560](https://customsspecialist16th.files.wordpress.com/2018/09/e0b884e0b8b3e0b8a8e0b8b1e0b89ee0b897e0b98ce0b8a0e0b8b2e0b8a9e0b8b2e0b8ade0b8b1e0b887e0b881e0b8a4e0b8a9e0b895e0b8b2e0b8a1e0b89ee0b8a3.pdf "คำศัพท์ภาษาอังกฤษตามพระราชบัญญัติศุลกาก")

[พระราชบัญญัติศุลกากร พ.ศ. 2560](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3-e0b89e-e0b8a82.pdf "พระราชบัญญัติศุลกากร พ.ศ. 2560")

[พระราชบัญญัติ การรับขนของทางถนนระหว่างประเทศ](http://web.krisdika.go.th/data/law/law2/%A1140/%A1140-20-2556-a0001.htm)

[พระราชบัญญัติการขนส่งต่อเนื่องหลายรูปแบบ พ.ศ. ๒๕๔๘](https://customsspecialist16th.files.wordpress.com/2018/10/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b881e0b8b2e0b8a3e0b882e0b899e0b8aae0b988e0b887e0b895.pdf "พระราชบัญญัติการขนส่งต่อเนื่องหลายรูปแบบ พ.ศ. ๒๕๔๘")

[พระราชบัญญัติการรับขนของทางทะเล พ.ศ. ๒๕๓๔](https://customsspecialist16th.files.wordpress.com/2018/10/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b881e0b8b2e0b8a3e0b8a3e0b8b1e0b89ae0b882e0b899e0b882.pdf "พระราชบัญญัติการรับขนของทางทะเล พ.ศ. ๒๕๓๔")

[พระราชบัญญัติการรับขนทางอากาศระหว่างประเทศ พ.ศ. ๒๕๕๘](https://customsspecialist16th.files.wordpress.com/2018/10/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b881e0b8b2e0b8a3e0b8a3e0b8b1e0b89ae0b882e0b899e0b897.pdf "พระราชบัญญัติการรับขนทางอากาศระหว่างประเทศ พ.ศ. ๒๕๕๘")

[การปฏิบัติพิธีการศุลกากรทางอิเล็กทรอนิกส์สำหรับการเชื่อมโยงข้อมูล NSW](https://customsspecialist16th.files.wordpress.com/2018/09/e0b881e0b8b2e0b8a3e0b89be0b88fe0b8b4e0b89ae0b8b1e0b895e0b8b4e0b89ee0b8b4e0b898e0b8b5e0b881e0b8b2e0b8a3e0b8a8e0b8b8e0b8a5e0b881e0b8b2.pdf "การปฏิบัติพิธีการศุลกากรทางอิเล็กทรอนิกส์สำหรับการเชื่อมโยงข้อ")

[การผ่อนผันให้จัดรวมรายการสินค้าในใบขนสินค้าขาเข้า](https://customsspecialist16th.files.wordpress.com/2018/09/e0b881e0b8b2e0b8a3e0b89ce0b988e0b8ade0b899e0b89ce0b8b1e0b899e0b983e0b8abe0b989e0b888e0b8b1e0b894e0b8a3e0b8a7e0b8a1e0b8a3e0b8b2e0b8a2.pdf "การผ่อนผันให้จัดรวมรายการสินค้าในใบขนสินค้าขาเข้า")

[การยกเว้นอากรสำหรับของส่วนตัวและของใช้ในบ้านเรือน (ตอนที่ 1)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b881e0b8b2e0b8a3e0b8a2e0b881e0b980e0b8a7e0b989e0b899e0b8ade0b8b2e0b881e0b8a3e0b8aae0b8b3e0b8abe0b8a3e0b8b1e0b89ae0b882e0b8ade0b887.pdf)

[การยกเว้นอากรสำหรับของส่วนตัวและของใช้ในบ้านเรือน (ตอนที่ 2)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b881e0b8b2e0b8a3e0b8a2e0b881e0b980e0b8a7e0b989e0b899e0b8ade0b8b2e0b881e0b8a3e0b8aae0b8b3e0b8abe0b8a3e0b8b1e0b89ae0b882e0b8ade0b8871.pdf)

[ประกาศกระทรวงพาณิชย์ การแก้ไขพิกัดอัตราศุลกากรฯ ฉ2 2555 พศ2556](https://customsspecialist16th.files.wordpress.com/2018/09/2648_0_e0b89be0b8a3e0b8b0e0b881e0b8b2e0b8a8e0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b89ee0b8b2e0b893e0b8b4e0b88ae0b8a2e0b98c-e0b881.pdf "2648_0_ประกาศกระทรวงพาณิชย์ การแก้ไขพิกัดอัตราศุลกากรฯ ฉ2 2555 พศ2556")

[ประมวลกฎหมายวิธีพิจารณาความอาญา](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89be0b8a3e0b8b0e0b8a1e0b8a7e0b8a5e0b881e0b88ee0b8abe0b8a1e0b8b2e0b8a2e0b8a7e0b8b4e0b898e0b8b5e0b89ee0b8b4e0b888e0b8b2e0b8a3e0b893.pdf "ประมวลกฎหมายวิธีพิจารณาความอาญา_")

[ประมวลกฎหมายวิธีพิจารณาความแพ่ง](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89be0b8a3e0b8b0e0b8a1e0b8a7e0b8a5e0b881e0b88ee0b8abe0b8a1e0b8b2e0b8a2e0b8a7e0b8b4e0b898e0b8b5e0b89ee0b8b4e0b888e0b8b2e0b8a3e0b8931.pdf "ประมวลกฎหมายวิธีพิจารณาความแพ่ง")

[พระราชบัญญัติการอํานวยความสะดวกในการอนุญาตของทางราชการ พ.ศ.2558](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b881e0b8b2e0b8a3e0b8ade0b98de0b8b2e0b899e0b8a7e0b8a2.pdf "พระราชบัญญัติการอํานวยความสะดวกในการอนุญาตของทางราชการ พ.ศ.2558")

[คู่มือฯ การตรวจสอบและออกใบรับรองฯ 2560](https://customsspecialist16th.files.wordpress.com/2018/09/e0b884e0b8b9e0b988e0b8a1e0b8b7e0b8ade0b8af-e0b881e0b8b2e0b8a3e0b895e0b8a3e0b8a7e0b888e0b8aae0b8ade0b89ae0b981e0b8a5e0b8b0e0b8ade0b8ad.pdf "คู่มือฯ การตรวจสอบและออกใบรับรองฯ 2560")

[พ.ร.บ. วิธีปฏิบัติราชการทางปกครอง พ.ศ. 2557](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89e-e0b8a3-e0b89a-e0b8a7e0b8b4e0b898e0b8b5e0b89be0b88fe0b8b4e0b89ae0b8b1e0b895e0b8b4e0b8a3e0b8b2e0b88ae0b881e0b8b2e0b8a3e0b897.pdf "พ.ร.บ. วิธีปฏิบัติราชการทางปกครอง พ.ศ. 2557")

[เรื่อง การลดอัตราอากรและยกเว้นอากรศุลกากร 2530](https://customsspecialist16th.files.wordpress.com/2018/09/f_12_2555e0b980e0b8a3e0b8b7e0b988e0b8ade0b887-e0b881e0b8b2e0b8a3e0b8a5e0b894e0b8ade0b8b1e0b895e0b8a3e0b8b2e0b8ade0b8b2e0b881e0b8a3e0b981.pdf "F_12_2555เรื่อง การลดอัตราอากรและยกเว้นอากรศุลกากร 2530")

[E -Register](https://customsspecialist16th.files.wordpress.com/2018/09/e-register.pdf)

[E -Tracking](https://customsspecialist16th.files.wordpress.com/2018/09/e-tracking.pdf)

[E-Bill Payment](https://customsspecialist16th.files.wordpress.com/2018/09/e-bill-payment.pdf)

[ระเบียบปฏิบัติเกี่ยวกับตัวแทนออกของหรือผู้ปฏิบัติ](https://customsspecialist16th.files.wordpress.com/2018/09/e0b8a3e0b8b0e0b980e0b89ae0b8b5e0b8a2e0b89ae0b89be0b88fe0b8b4e0b89ae0b8b1e0b895e0b8b4e0b980e0b881e0b8b5e0b988e0b8a2e0b8a7e0b881e0b8b1.pdf "ระเบียบปฏิบัติเกี่ยวกับตัวแทนออกของหรือผู้ปฏิบัติงานเกี่ยวกับก")[งานกับกรมศุลกากร](https://customsspecialist16th.files.wordpress.com/2018/09/e0b8a3e0b8b0e0b980e0b89ae0b8b5e0b8a2e0b89ae0b89be0b88fe0b8b4e0b89ae0b8b1e0b895e0b8b4e0b980e0b881e0b8b5e0b988e0b8a2e0b8a7e0b881e0b8b1.pdf "ระเบียบปฏิบัติเกี่ยวกับตัวแทนออกของหรือผู้ปฏิบัติงานเกี่ยวกับก")

[๑.กฎกระทรวงกำหนดด่านศุลกากรและด่านพรมแดน พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b991-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b3e0b8abe0b899e0b894e0b894e0b988e0b8b2e0b899e0b8a8e0b8b8e0b8a51.pdf "๑.กฎกระทรวงกำหนดด่านศุลกากรและด่านพรมแดน พ.ศ. ๒๕๖๐")

[๒.กฎกระทรวงกำหนดค่าธรรมเนียมและยกเว้นค่าธรรมเนียม พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b992-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b3e0b8abe0b899e0b894e0b884e0b988e0b8b2e0b898e0b8a3e0b8a3e0b8a1.pdf "๒.กฎกระทรวงกำหนดค่าธรรมเนียมและยกเว้นค่าธรรมเนียม พ.ศ. ๒๕๖๐")

[๓.กฎกระทรวงกำหนดการยื่นใบขนสินค้าและการเสียอากรสำหรับก๊าซธรรมชาติและพลังงานไฟฟ้าที่นำเข้ามาในหรือส่งออกไปนอกราชอาณาจักร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file.pdf)

[๔.กฎกระทรวงกำหนดชนิดหรือประเภท การเก็บและการขนถ่ายและการจัดเก็บอากร สำหรับสินค้าอันตราย พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b994-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b3e0b8abe0b899e0b894e0b88ae0b899e0b8b4e0b894e0b8abe0b8a3e0b8b7.pdf)

[๕.กฎกระทรวงกำหนดค่าใช้จ่ายการเก็บรักษาของในที่เก็บรักษาหรือในคลังสินค้าของศุลกากร พ.ศ ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-1.pdf)

[๖.กฎกระทรวงกำหนดหลักเกณฑ์การลดเงินเพิ่ม พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b996-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b3e0b8abe0b899e0b894e0b8abe0b8a5e0b8b1e0b881e0b980e0b881e0b8931.pdf)

[๗.กฎกระทรวงการกำหนดและการใช้ราคาศุลกากร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b997-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b2e0b8a3e0b881e0b8b3e0b8abe0b899e0b894e0b981e0b8a5e0b8b0e0b8811.pdf)

[๘.กฎกระทรวงการอนุญาตจัดตั้งและเลิกการดำเนินการคลังสินค้าทัณฑ์บน โรงพักสินค้า ที่มั่นคง และท่าเรือรับอนุญาต พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-2.pdf "๘.กฎกระทรวงการอนุญาตจัดตั้งและเลิกการดำเนินการคลังสินค้าทัณฑ์บน โรงพักสินค้า ที่มั่นคง และท่าเรือรับอนุญาต พ.ศ. ๒๕๖๐")

[๙.กฎกระทรวงการอนุญาตจัดตั้งและการเลิกดำเนินการเขตปลอดอากร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-3.pdf)

[๑๐.กฎกระทรวงการอนุญาตประกอบกิจการในเขตปลอดอากร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b991e0b990-e0b881e0b88ee0b881e0b8a3e0b8b0e0b897e0b8a3e0b8a7e0b887e0b881e0b8b2e0b8a3e0b8ade0b899e0b8b8e0b88de0b8b2e0b895e0b89be0b8a31.pdf "๑๐.กฎกระทรวงการอนุญาตประกอบกิจการในเขตปลอดอากร พ.ศ. ๒๕๖๐")

[๑๑.กฎกระทรวงการยกเว้นอากรสำหรับของที่นำเข้ามาในราชอาณาจักรเพื่อนำเข้าไปในเขตปลอดอากรและของที่ปล่อยออกไปจากเขตปลอดอากรเพื่อส่งออกไปนอกราชอาณาจักร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-4.pdf "๑๑.กฎกระทรวงการยกเว้นอากรสำหรับของที่นำเข้ามาในราชอาณาจักรเพื่อนำเข้าไปในเขตปลอดอากรและของที่ปล่อยออกไปจากเขตปลอดอากรเพื่อส่งออกไปนอกราชอาณาจักร พ.ศ. ๒๕๖๐")

[๑๒.กฎกระทรวงกำหนดพื้นที่ที่ได้รับยกเว้นไม่อยู่ภายใต้บังคับของกฎหมายในส่วนที่เกี่ยวกับการควบคุมการนำเข้ามาในราชอาณาจักร การส่งออกไปนอกราชอาณาจักรการครอบครองหรือการใช้ประโยชน์ซึ่งของในเขตปลอดอากร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-5.pdf)

[๑๓.กฎกระทรวงกำหนดเวลาทำการบรรทุกหรือขนถ่ายของหรือกระทำการที่ต้องมีพนักงานศุลกากรกำกับ พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file-6.pdf)

[คู่มือพิธีการศุลกากรผ่านแดนอาเซียน](https://customsspecialist16th.files.wordpress.com/2018/09/e0b884e0b8b9e0b988e0b8a1e0b8b7e0b8ade0b89ee0b8b4e0b898e0b8b5e0b881e0b8b2e0b8a3e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3e0b89ce0b9881.pdf)

[พระราชกฤษฎีกากำหนดเขตควบคุมศุลกากร พ.ศ. ๒๕๖๐](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b881e0b8a4e0b8a9e0b88ee0b8b5e0b881e0b8b2e0b881e0b8b3e0b8abe0b899e0b894e0b980e0b882e0b895e0b8841.pdf)

[พระราชกำหนดพิกัดอัตราศุลกากร พ.ศ. 2530 (ภาษาอังกฤษ)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b881e0b8b3e0b8abe0b899e0b894e0b89ee0b8b4e0b881e0b8b1e0b894e0b8ade0b8b1e0b895e0b8a3e0b8b2e0b8a82.pdf)

[พระราชกำหนดพิกัดอัตราศุลกากร พ.ศ.2530 (ฉบับแก้ไขล่าสุด)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b881e0b8b3e0b8abe0b899e0b894e0b89ee0b8b4e0b881e0b8b1e0b894e0b8ade0b8b1e0b895e0b8a3e0b8b2e0b8a83.pdf)

[พระราชบัญญัติแก้ไขเพิ่มเติมพระราชกำหนดพิกัดอัตราศุลกากร พ.ศ. 2530 ฉบับที่ 8 พ.ศ. 2557](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b981e0b881e0b989e0b984e0b882e0b980e0b89ee0b8b4e0b9881.pdf)

[พิกัดอัตราศุลกากร และรหัสสถิติที่ต้องมีใบอนุญาตและใบรับรอง](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8b4e0b881e0b8b1e0b894e0b8ade0b8b1e0b895e0b8a3e0b8b2e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3-e0b981e0b8a5e0b8b0e0b8a3e0b8ab.xlsx "พิกัดอัตราศุลกากร และรหัสสถิติที่ต้องมีใบอนุญาตและใบรับรอง")

[การปฏิบัติพิธีการศุลกากรทางอิเล็กทรอนิกส์สำหรับการเชื่อมโยงข้อมูลตามกฎหมายอื่นที่เกี่ยวข้องกับการศุลกากร](https://customsspecialist16th.files.wordpress.com/2018/09/e0b881e0b8b2e0b8a3e0b89be0b88fe0b8b4e0b89ae0b8b1e0b895e0b8b4e0b89ee0b8b4e0b898e0b8b5e0b881e0b8b2e0b8a3e0b8a8e0b8b8e0b8a5e0b881e0b8b21.pdf "การปฏิบัติพิธีการศุลกากรทางอิเล็กทรอนิกส์สำหรับการเชื่อมโยงข้อมูลตามกฎหมายอื่นที่เกี่ยวข้องกับการศุลกากร")

[พระราชบัญญัติ – สำนักอาหาร – กระทรวงสาธารณสุข](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4-e0b8aae0b8b3e0b899e0b8b1e0b881e0b8ade0b8b2e0b8ab.pdf "พระราชบัญญัติ - สำนักอาหาร - กระทรวงสาธารณสุข")

[พระราชบัญญัติ การส่งออกไปนอกและการนำเข้ามาในราชอาณาจักรซึ่งสินค้า พ.ศ. 2522-กระทรวงพานิชย์](https://customsspecialist16th.files.wordpress.com/2018/09/unnamed-file.doc)

[หลักเกณฑ์ และเงื่อนไข การเป็นผู้ชำนาญการศุลกากร](https://customsspecialist16th.files.wordpress.com/2018/09/e0b8abe0b8a5e0b8b1e0b881e0b980e0b881e0b893e0b891e0b98c-e0b981e0b8a5e0b8b0e0b980e0b887e0b8b7e0b988e0b8ade0b899e0b984e0b882-e0b881e0b8b2.pdf "หลักเกณฑ์ และเงื่อนไข การเป็นผู้ชำนาญการศุลกากร")

[คำอธิบายพิกัดศุลกากรเพิ่มเติม (Supplementary Explanatory Notes – SEN 2017) EN](https://customsspecialist16th.files.wordpress.com/2018/09/e0b884e0b8b3e0b8ade0b898e0b8b4e0b89ae0b8b2e0b8a2e0b89ee0b8b4e0b881e0b8b1e0b894e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3e0b980e0b89e.pdf)

[Text of AHTN 2017 with Corrigendum Oct 2016](https://customsspecialist16th.files.wordpress.com/2018/09/text-of-ahtn-2017-with-corrigendum-oct-2016.pdf)

[ตารางเทียบพิกัดศุลกากรประเภทย่อย AHTN 2012 – AHTN 2017](https://customsspecialist16th.files.wordpress.com/2018/09/e0b895e0b8b2e0b8a3e0b8b2e0b887e0b980e0b897e0b8b5e0b8a2e0b89ae0b89ee0b8b4e0b881e0b8b1e0b894e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3.pdf)

[ปรับปรุงแก้ไขรหัสสถิติ 2832.10 และ 2832.20 (8 มีนาคม 2560)](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89be0b8a3e0b8b1e0b89ae0b89be0b8a3e0b8b8e0b887e0b981e0b881e0b989e0b984e0b882e0b8a3e0b8abe0b8b1e0b8aae0b8aae0b896e0b8b4e0b895e0b8b4-2.xlsx)

[พระราชกำหนดพิกัดอัตราศุลกากร (ฉบับที่ 6) พ.ศ. 2559](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b881e0b8b3e0b8abe0b899e0b894e0b89ee0b8b4e0b881e0b8b1e0b894e0b8ade0b8b1e0b895e0b8a3e0b8b2e0b8a84.pdf)

[ราชกิจจานุเบกษา แก้คำผิด พระราชกำหนดพิกัดอัตราศุลกากร (ฉบับที่ 6) พ.ศ.2560](https://customsspecialist16th.files.wordpress.com/2018/09/e0b8a3e0b8b2e0b88ae0b881e0b8b4e0b888e0b888e0b8b2e0b899e0b8b8e0b980e0b89ae0b881e0b8a9e0b8b2-e0b981e0b881e0b989e0b884e0b8b3e0b89ce0b8b4.pdf)

[Check List FORM FTA of 15 jan 2018](https://customsspecialist16th.files.wordpress.com/2018/09/check-list-form-fta-of-15-jan-2018.pdf)

[สินค้าเหล็กที่มีมาตรการตอบโต้การทุ่มตลาดและการอุดหนุน 2018](http://www.customs.go.th/data_files/6799ef2d549e5fbd543ce92c78cc2ff4/mobile/index.html)

[ระบบอัตโนมัติเพื่อการจำแนกพิกัดศุลกากรในโลกอนาคต](http://www.customs.go.th/data_files/9de29ff98cc6a7c3e35240c5c5b04a1f/mobile/index.html)

[ความรู้ด้านพิกัดศุลกากร เล่มที่ 1](http://www.customs.go.th/data_files/fe472497ed4ad1dc2937468735435041/mobile/index.html#p=1)

[การจำแนกพิกัดอัตราศุลกากรตอนที่ 23 และตอนที่ 28](http://www.customs.go.th/data_files/c7041b430016c37730c3466441b841e5/mobile/index.html#p=1)

[การตรวจสินคัากระเบื้องเซรามิกตามประเภทพิกัด 69.07](http://www.customs.go.th/data_files/d0aa668c95c30e39051fccddf98a3804/mobile/index.html#p=1)

[การตรวจวิเคราะห์สินค้าทองคำและทองคำเจือ](http://www.customs.go.th/data_files/e0eb96385eec41ac4217fe184d3d5cb3/mobile/index.html)

[ศัพท์ภาษาอังกฤษที่ใช้งานด้านพิกัดศุลกากร1](http://www.customs.go.th/data_files/72857266829009765fcca9476cc240de/mobile/index.html)

[ศัพท์ภาษอังกฤษที่ใช้งานด้านพิกัดศุลกากร2](http://www.customs.go.th/data_files/ec7ca0924aa54b9ee85594ce34f5d6bb/mobile/index.html#p=1)

[พิกัดศุลกากร ภาษาอังกฤษ](https://customsspecialist16th.files.wordpress.com/2018/09/e0b89ee0b8b4e0b881e0b8b1e0b894e0b8a8e0b8b8e0b8a5e0b881e0b8b2e0b881e0b8a3-e0b8a0e0b8b2e0b8a9e0b8b2e0b8ade0b8b1e0b887e0b881e0b8a4e0b8a9.pdf)

[ASEAN | ONE VISION ONE IDENTITY ONE COMMUNITY](https://asean.org/?static_post=annex-2-tariff-schedules)

[กฎว่าด้วยถิ่นกำเนิดสินค้า](https://customsspecialist16th.files.wordpress.com/2018/10/e0b881e0b88ee0b8a7e0b988e0b8b2e0b894e0b989e0b8a7e0b8a2e0b896e0b8b4e0b988e0b899e0b881e0b8b3e0b980e0b899e0b8b4e0b894e0b8aae0b8b4e0b899.pdf)

[สรุปตารางถิ่นกำเนิดสินค้า](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8aae0b8a3e0b8b8e0b89be0b895e0b8b2e0b8a3e0b8b2e0b887e0b896e0b8b4e0b988e0b899e0b881e0b8b3e0b980e0b899e0b8b4e0b894e0b8aae0b8b4e0b899.pdf)

[ประกาศกรมฯ 159-2560](https://customsspecialist16th.files.wordpress.com/2018/10/e0b89be0b8a3e0b8b0e0b881e0b8b2e0b8a8e0b881e0b8a3e0b8a1e0b8af-159-2560.pdf)

[ประกาศ 187-2560 อาเซียน](https://customsspecialist16th.files.wordpress.com/2018/10/e0b89be0b8a3e0b8b0e0b881e0b8b2e0b8a8-187-2560-e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899.pdf)

[อาเซียน เอกสารแนบ 1 ± ( st criterion for textiles-textile products ) hs 2012](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899-e0b980e0b8ade0b881e0b8aae0b8b2e0b8a3e0b981e0b899e0b89a-1-c2b1-st-criterion-for-textiles-textile-products.pdf)

[อาเซียนเอกสารแนบ2 ≥ chapter 3 – ROO](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b980e0b8ade0b881e0b8aae0b8b2e0b8a3e0b981e0b899e0b89a2-e289a5-chapter-3-roo.pdf)

[อาเซียน ภาคผนวก3 ≤ psr hs2012](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899-e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b8813-e289a4-psr-hs2012.pdf)

[อาเซียนเอกสารแนบ3 ≤ hs2012 to hs2017](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b980e0b8ade0b881e0b8aae0b8b2e0b8a3e0b981e0b899e0b89a3-e289a4-hs2012-to-hs2017.pdf)

[อาเซียนเอกสารแนบ4](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b980e0b8ade0b881e0b8aae0b8b2e0b8a3e0b981e0b899e0b89a4.pdf)

[อาเซียน ภาคผนวก4 ita2012](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899-e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b8814-ita2012.pdf)

[อาเซียนภาคผนวก 5 principles&amp;guidelines for calculating RVC](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b881-5-principlesguidelines-for-calculating-rvc.pdf "อาเซียนภาคผนวก 5 principles&amp;guidelines for calculating rvc")

[อาเซียนภาคผนวก 6 (Implementing Guidelines for Partial Cumulation)](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b881-6-implementing-guidelines-for-partial-cumulation.pdf "อาเซียนภาคผนวก 6 (implementing guidelines for partial cumulation)")

[อาเซียนภาคผนวก 7≈ Form D](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b881-7e28988-form-d.pdf)

[อาเซียน ถาคผนวก 8( e-Form D)](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899-e0b896e0b8b2e0b884e0b89ce0b899e0b8a7e0b881-8-e-form-d.pdf)

[อาเซียนภาคผนวก 9](https://customsspecialist16th.files.wordpress.com/2018/10/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899e0b8a0e0b8b2e0b884e0b89ce0b899e0b8a7e0b881-9.pdf)

[คู่มือ กฎแหล่งกำเนิดสินค้าภายใต้ FTA](https://customsspecialist16th.files.wordpress.com/2018/10/e0b884e0b8b9e0b988e0b8a1e0b8b7e0b8ad-e0b881e0b88ee0b981e0b8abe0b8a5e0b988e0b887e0b881e0b8b3e0b980e0b899e0b8b4e0b894e0b8aae0b8b4e0b899.pdf)

[ประกาศกระทรวงการคลังเรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](https://customsspecialist16th.files.wordpress.com/2018/11/atiga_new_25602.pdf)

[ประกาศกระทรวงการคลัง เรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับเขตการค้าเสรีอาเซียน – จีน ลงวันที่ 10 พฤศจิกายน 2560](https://customsspecialist16th.files.wordpress.com/2018/11/e0b8ade0b8b2e0b980e0b88be0b8b5e0b8a2e0b899-e28093-e0b888e0b8b5e0b899-e0b8a5e0b887e0b8a7e0b8b1e0b899e0b897e0b8b5e0b988-10-e0b89ee0b8a4.pdf)

[มาตรา 12 ประกาศ 10 พฤศจิกายน 2560](https://customsspecialist16th.files.wordpress.com/2018/11/e0b8a1e0b8b2e0b895e0b8a3e0b8b212-10-e0b89ee0b8a4e0b8a8e0b888e0b8b4e0b881e0b8b2e0b8a2e0b899-2560.pdf)

[ประกาศที่ 119 2561](https://customsspecialist16th.files.wordpress.com/2018/11/e0b89be0b8a3e0b8b0e0b881e0b8b2e0b8a8e0b897e0b8b5e0b988-119-2561.pdf)

[สารบัญ119](https://customsspecialist16th.files.wordpress.com/2018/11/e0b8aae0b8b2e0b8a3e0b89ae0b8b1e0b88d119.pdf)

[คู่มือ 119](https://customsspecialist16th.files.wordpress.com/2018/11/e0b884e0b8b9e0b988e0b8a1e0b8b7e0b8ad-119.pdf)

[พระราชบัญญัติส่งเสริมการลงทุน พ.ศ.2520 (ฉบับที่ 4) – BOI](https://customsspecialist16th.files.wordpress.com/2018/11/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b8aae0b988e0b887e0b980e0b8aae0b8a3e0b8b4e0b8a1e0b881.pdf)

[พระราชบัญญัติการนิคมอุตสาหกรรมแห่งประเทศไทย (ฉบับที่ 4) พ.ศ. 2550](https://customsspecialist16th.files.wordpress.com/2018/11/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b881e0b8b2e0b8a3e0b899e0b8b4e0b884e0b8a1e0b8ade0b8b8.pdf)

[พระราชบัญญัติชดเชยค่าภาษีอากรสินค้าส่งออกที่ผลิตในราชอาณาจักร พ.ศ. ๒๕๒๔](https://customsspecialist16th.files.wordpress.com/2018/11/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b88ae0b894e0b980e0b88ae0b8a2e0b884e0b988e0b8b2e0b8a0.pdf)

[พระราชบัญญัติวัตถุอันตราย พ.ศ. 2535.](https://customsspecialist16th.files.wordpress.com/2018/11/e0b89ee0b8a3e0b8b0e0b8a3e0b8b2e0b88ae0b89ae0b8b1e0b88de0b88de0b8b1e0b895e0b8b4e0b8a7e0b8b1e0b895e0b896e0b8b8e0b8ade0b8b1e0b899e0b895.pdf)

> [Source](https://customsspecialist16th.wordpress.com/)