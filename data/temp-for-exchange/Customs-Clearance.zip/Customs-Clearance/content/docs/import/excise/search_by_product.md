---
weight: 3
bookToc: false
title: สืบค้นรหัสสินค้าสรรพสามิต
bookCollapseSection: true
---

สืบค้นรหัสสินค้าสรรพสามิตสำหรับระบบแลกเปลี่ยนข้อมูลอิเล็กทรอนิกส์
==

**สืบค้นตามชนิดสินค้า**


| ชนิดสินค้า      |     ชื่อสินค้า |
|:-----------:|-----------------------------------------------------|
|ตอนที่ 1   |[สินค้าน้ำมันและผลิตภัณฑ์น้ำมัน](http://edi.excise.go.th/form_search_by_product.php?product_code=0100&search=S&menu=2)|
|ตอนที่ 2| [สินค้าเครื่องดื่ม](http://edi.excise.go.th/form_search_by_product.php?product_code=0200&search=S&menu=2)|
|ตอนที่ 3| [สินค้าเครื่องไฟฟ้า](http://edi.excise.go.th/form_search_by_product.php?product_code=0300&search=S&menu=2)|
|ตอนที่ 4 |[สินค้าแบตเตอรี่](http://edi.excise.go.th/form_search_by_product.php?product_code=0400&search=S&menu=2)|
|ตอนที่ 5| [สินค้าแก้วและเครื่องแก้ว](http://edi.excise.go.th/form_search_by_product.php?product_code=0500&search=S&menu=2)|
|ตอนที่ 6 |[สินค้ารถยนต์](http://edi.excise.go.th/form_search_by_product.php?product_code=0600&search=S&menu=2)|
|ตอนที่ 7 |[สินค้ารถจักรยานยนต์](http://edi.excise.go.th/form_search_by_product.php?product_code=0700&search=S&menu=2)|
|ตอนที่ 8| [สินค้าเรือ](http://edi.excise.go.th/form_search_by_product.php?product_code=0800&search=S&menu=2)|
|ตอนที่ 9| [สินค้าผลิตภัณฑ์เครื่องหอมและเครื่องสำอาง](http://edi.excise.go.th/form_search_by_product.php?product_code=0900&search=S&menu=2)|
|ตอนที่ 10| [สินค้าพรมและสิ่งทอปูพื้น](http://edi.excise.go.th/form_search_by_product.php?product_code=1000&search=S&menu=2)|
|ตอนที่ 11 |[สินค้าหินอ่อนและหินแกรนิต](http://edi.excise.go.th/form_search_by_product.php?product_code=1100&search=S&menu=2)|
|ตอนที่ 12|[สินค้าทำลายชั้นบรรยากาศโอโซน](http://edi.excise.go.th/form_search_by_product.php?product_code=1200&search=S&menu=2)|
|ตอนที่ 13 |[สินค้าสุรา](http://edi.excise.go.th/form_search_by_product.php?product_code=1300&search=S&menu=2)|
|ตอนที่ 14| [สินค้ายาสูบ](http://edi.excise.go.th/form_search_by_product.php?product_code=1400&search=S&menu=2)|
|ตอนที่ 15 |[สินค้าไพ่](http://edi.excise.go.th/form_search_by_product.php?product_code=1500&search=S&menu=2)|
|ตอนที่ 16| [สินค้าอื่่น ๆ](http://edi.excise.go.th/form_search_by_product.php?product_code=1600&search=S&menu=2)|
|**ALL**| [ค้นหาทั้งหมด](http://edi.excise.go.th/form_search_by_product.php?product_code=&search=S&menu=2)|
