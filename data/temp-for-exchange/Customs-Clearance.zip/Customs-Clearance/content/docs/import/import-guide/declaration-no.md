---
weight: 3
bookFlatSection: true
title: 3. รูปแบบเลขที่ใบขนสินค้า
bookToc: false
---

รูปแบบเลขที่ใบขนสินค้า
===

![enter image description here](https://github.com/yosarawut/WorkingArea/raw/master/KnowledgeCenter/e-Customs/e-Import/e-Import-manual/img/e-Import_2018png_Page52.png)