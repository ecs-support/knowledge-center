---
weight: 22
bookFlatSection: true
title: 22. Payment Method and Guarantee Method Guideline
bookToc: false
---


Payment Method and Guarantee Method Guideline
===

![Payment Method and Guarantee Method Guideline](https://github.com/yosarawut/WorkingArea/raw/master/KnowledgeCenter/img/Payment-Method.png)

**หมายเหตุ**

ถ้า **Total Payment Amount**  มีค่าต้องระบุ ข้อมูลดังต่อไปนี้ด้วย
{{< hint danger >}}
- Bank Code	
- Bank Branch Code
- Bank Account Number
- Customs Bank Code
{{< /hint  >}}	

ถ้า **Total Deposit Amount** มีค่าต้องระบุ ข้อมูลดังต่อไปนี้ด้วย
{{< hint danger >}}
- Guarantee Bank Code
- Guarantee Bank Branch Code
- Guarantee Bank Account Number (ถ้ามี)
{{< /hint  >}}