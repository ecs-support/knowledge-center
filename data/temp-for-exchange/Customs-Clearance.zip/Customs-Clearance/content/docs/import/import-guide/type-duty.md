---
weight: 24
bookFlatSection: true
title: 24. ประเภทค่าภาษีอากร
bookToc: false
---

# ประเภทค่าภาษีอากรที่ต้องชำระและ/หรือวางประกัน  (Duty Type)  

![ประเภทค่าภาษีอากร](https://github.com/yosarawut/KnowledgeCenter/raw/master/KnowledgeCenter/e-Customs/e-Import/e-Import-manual/img/e-Import_2018png_Page122.png)