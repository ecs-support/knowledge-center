---

weight: 2
bookFlatSection: true
title: 2. การคำนวณมูลค่าเงินนำเข้า
bookToc: false
---

การตรวจสอบผลการคำนวณมูลค่าเงินนำเข้า เงินบาท และเงินต่างประเทศ ในใบขนสินค้าขาเข้า
===

![enter image description here](https://github.com/yosarawut/WorkingArea/raw/master/KnowledgeCenter/img/30-07-2019%2017-04-55.jpg)