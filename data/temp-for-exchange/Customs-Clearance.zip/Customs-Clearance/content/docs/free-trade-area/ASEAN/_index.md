---
title: เขตการค้าเสรีอาเซียน (AFTA)
bookCollapseSection: true
weight: 2
bookToc: false
---

เขตการค้าเสรีอาเซียน (ASEAN Free Trade Area: AFTA)
====

![enter image description here](https://www.worldatlas.com/r/w728-h425-c728x425/upload/21/c9/14/shutterstock-194495666.jpg)

เขตการค้าเสรีอาเซียน (AFTA) เกิดจากความต้องการร่วมมือทางการค้าจากประเทศต่างๆในอาเซียน เพื่อให้อาเซียนเป็นภูมิภาคที่มีศักยภาพทางด้านเศรษฐกิจ และเพิ่มอำนาจในการต่อรองทางด้านเศรษฐกิจในเวทีโลก พร้อมกันนี้อาเซียนยังมีความต้องการที่จะดึงดูดประเทศต่างๆให้เข้ามาลงทุน เพื่อความเจริญเติบโตอย่างต่อเนื่องภายในภูมิภาค โดย AFTA นั้น จะทำให้การค้าขายสินค้าในอาเซียนเป็นไปอย่างเสรี มีการคิดอัตราภาษีระหว่างกันในระดับที่ต่ำ และปราศจากข้อกำหนดทางการค้า อันจะส่งผลให้ประเทศสมาชิกจะมีต้นทุนการผลิตสินค้าที่ลดลง อีกทั้งเป็นการเพิ่มปริมาณทางด้านการค้าในภูมิภาคให้มีมากขึ้น ทำให้อาเซียนเป็นภูมิภาคที่มีการเติบโตทางเศรษฐกิจอย่างรวดเร็วและมั่นคง  

อาเซียนดำเนินการจัดตั้งเขตการค้าเสรีอาเซียน (AFTA) โดยมุ่งเน้นไปที่การขจัดอุปสรรคทางการค้าทั้งหลายภายในภูมิภาค ทั้งในด้านภาษีและเครื่องกีดขวางทางการค้าต่างๆที่มิใช่ภาษี ยกตัวอย่างเช่น การจำกัดโควต้าการนำเข้า เป็นต้น โดยจะยกเว้นแต่เพียงสินค้าที่มีผลกระทบต่อความมั่นคง ศีลธรรม ชีวิต และศิลปะ เท่านั้น ซึ่งมาตรการที่สำคัญที่สุดก็คงจะหนีไม่พ้นมาตรการทางภาษี โดยอาเซียนมีเป้าหมายในการลดภาษีในบัญชีลดภาษี (IL) ให้เหลือร้อยละ 0-5 ภายในค.ศ.2002 และตั้งเป้าให้เหลือร้อยละ 0 ภายใน ค.ศ.2010 สำหรับประเทศ ASEAN 6 (ประเทศไทย ประเทศอินโดนีเซีย ประเทศมาเลเซีย ประเทศสิงคโปร์ ประเทศฟิลิปปินส์ และประเทศบรูไน) ยกเว้น สินค้าอ่อนไหว (SL) เช่น กลุ่มสินค้าประเภทมันฝรั่ง กาแฟของประเทศไทย หรือ กลุ่มสินค้าประเภท กาแฟ ชา ของประเทศบรูไน เป็นต้น โดยสินค้าประเภทนี้กำหนดให้ต้องลดภาษีเหลือ 0-5% ภายใน ค.ศ.2010 และยกเลิกมาตรการที่มิใช่ภาษี และยกเว้นรายการสินค้าอ่อนไหวสูง (HSL) เช่น กลุ่มสินค้าประเภทข้าวของมาเลเซีย ที่จะต้องลดภาษีจากร้อยละ 40 ให้เหลือร้อยละ 20 ในค.ศ.2010 สำหรับกลุ่มประเทศ CLMV (ประเทศลาว ประเทศเวียดนาม ประเทศเมียนมาร์ และประเทศกัมพูชา) นั้น ได้มีเป้าหมายในการลดภาษีในบัญชีลดภาษี (IL) ให้เหลือ ร้อยละ 0-5 ภายใน ค.ศ.2010 และตั้งเป้าให้เหลือร้อยละ 0 ภายใน ค.ศ.2015 ยกเว้นสินค้าอ่อนไหว (SL) และสินค้าอ่อนไหวสูง (HSL) เช่นเดียวกัน โดยการกำหนดมาตรการดังกล่าวก็เพื่อให้สอดคล้องกับเป้าหมายของประชาคมเศรษฐกิจอาเซียน (AEC) ที่มุ่งเป็นตลาดเดียวและฐานการผลิตร่วมกัน และเป้าหมายในการเชื่อมโยงเศรษฐกิจอาเซียนกับเศรษฐกิจโลกด้วย

## การสงวนสิทธิ์ขอใช้สิทธิพิเศษทางภาษีศุลกากร

![](https://github.com/ecs-support/knowledge-center/raw/master/img/ATIGA-01.jpg)

ที่มา : [ประกาศกรมศุลกากรที่ 187/ 2560 เรื่อง หลักเกณฑ์และพิธีการการยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=14223132414c505f46464a4f464b4c)

#### ประเทศสมาชิก

[![ประเทศกัมพูชา](https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Flag_of_Cambodia.svg/23px-Flag_of_Cambodia.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%81%E0%B8%B1%E0%B8%A1%E0%B8%9E%E0%B8%B9%E0%B8%8A%E0%B8%B2 "ประเทศกัมพูชา")  [กัมพูชา](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%81%E0%B8%B1%E0%B8%A1%E0%B8%9E%E0%B8%B9%E0%B8%8A%E0%B8%B2 "ประเทศกัมพูชา")  ·  [![ไทย](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Flag_of_Thailand.svg/23px-Flag_of_Thailand.svg.png)](https://th.wikipedia.org/wiki/%E0%B9%84%E0%B8%97%E0%B8%A2 "ไทย")  [ไทย](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B9%84%E0%B8%97%E0%B8%A2 "ประเทศไทย")  ·  [![บรูไน](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Flag_of_Brunei.svg/23px-Flag_of_Brunei.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%9A%E0%B8%A3%E0%B8%B9%E0%B9%84%E0%B8%99 "บรูไน")  [บรูไน](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%9A%E0%B8%A3%E0%B8%B9%E0%B9%84%E0%B8%99 "ประเทศบรูไน")  ·  [![ประเทศพม่า](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Flag_of_Myanmar.svg/23px-Flag_of_Myanmar.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%9E%E0%B8%A1%E0%B9%88%E0%B8%B2 "ประเทศพม่า")  [พม่า](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%9E%E0%B8%A1%E0%B9%88%E0%B8%B2 "ประเทศพม่า")  ·  [![ฟิลิปปินส์](https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Flag_of_the_Philippines.svg/23px-Flag_of_the_Philippines.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%9F%E0%B8%B4%E0%B8%A5%E0%B8%B4%E0%B8%9B%E0%B8%9B%E0%B8%B4%E0%B8%99%E0%B8%AA%E0%B9%8C "ฟิลิปปินส์")  [ฟิลิปปินส์](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%9F%E0%B8%B4%E0%B8%A5%E0%B8%B4%E0%B8%9B%E0%B8%9B%E0%B8%B4%E0%B8%99%E0%B8%AA%E0%B9%8C "ประเทศฟิลิปปินส์")  ·  [![มาเลเซีย](https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Flag_of_Malaysia.svg/23px-Flag_of_Malaysia.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%A1%E0%B8%B2%E0%B9%80%E0%B8%A5%E0%B9%80%E0%B8%8B%E0%B8%B5%E0%B8%A2 "มาเลเซีย")  [มาเลเซีย](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%A1%E0%B8%B2%E0%B9%80%E0%B8%A5%E0%B9%80%E0%B8%8B%E0%B8%B5%E0%B8%A2 "ประเทศมาเลเซีย")  ·  [![ลาว](https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Flag_of_Laos.svg/23px-Flag_of_Laos.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%A5%E0%B8%B2%E0%B8%A7 "ลาว")  [ลาว](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%A5%E0%B8%B2%E0%B8%A7 "ประเทศลาว")  ·  [![เวียดนาม](https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Flag_of_Vietnam.svg/23px-Flag_of_Vietnam.svg.png)](https://th.wikipedia.org/wiki/%E0%B9%80%E0%B8%A7%E0%B8%B5%E0%B8%A2%E0%B8%94%E0%B8%99%E0%B8%B2%E0%B8%A1 "เวียดนาม")  [เวียดนาม](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B9%80%E0%B8%A7%E0%B8%B5%E0%B8%A2%E0%B8%94%E0%B8%99%E0%B8%B2%E0%B8%A1 "ประเทศเวียดนาม")  ·  [![สิงคโปร์](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Flag_of_Singapore.svg/23px-Flag_of_Singapore.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%AA%E0%B8%B4%E0%B8%87%E0%B8%84%E0%B9%82%E0%B8%9B%E0%B8%A3%E0%B9%8C "สิงคโปร์")  [สิงคโปร์](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%AA%E0%B8%B4%E0%B8%87%E0%B8%84%E0%B9%82%E0%B8%9B%E0%B8%A3%E0%B9%8C "ประเทศสิงคโปร์")  ·  [![อินโดนีเซีย](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Flag_of_Indonesia.svg/23px-Flag_of_Indonesia.svg.png)](https://th.wikipedia.org/wiki/%E0%B8%AD%E0%B8%B4%E0%B8%99%E0%B9%82%E0%B8%94%E0%B8%99%E0%B8%B5%E0%B9%80%E0%B8%8B%E0%B8%B5%E0%B8%A2 "อินโดนีเซีย")  [อินโดนีเซีย](https://th.wikipedia.org/wiki/%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%97%E0%B8%A8%E0%B8%AD%E0%B8%B4%E0%B8%99%E0%B9%82%E0%B8%94%E0%B8%99%E0%B8%B5%E0%B9%80%E0%B8%8B%E0%B8%B5%E0%B8%A2 "ประเทศอินโดนีเซีย")

## ประกาศ / กฎหมาย ที่เกี่ยวข้อง

{{< tabs "uniqueid" >}}
{{< tab "ประกาศกระทรวงการคลัง" >}} 
#### ประกาศกระทรวงการคลัง

-   [ประกาศกระทรวงการคลัง เรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน ลงวันที่ 10 พฤศจิกายน 2560](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=14223132414c505e4f464a4e464b48)
-   [ประกาศกระทรวงการคลัง เรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน (30 ธันวาคม 2559)](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142231324149505f46464b4a464b4b)
-   [ประกาศกระทรวงการคลัง เรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน (ฉบับที่ 2)](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142231324147505f49464b49464b49)
-   [ประกาศกระทรวงการคลัง เรื่อง การยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142231324147505f49464b49464b48)

{{< /tab >}}
{{< tab "ประกาศกรมศุลกากร" >}}

#### ประกาศกรมศุลกากร

|เลขที่ประกาศ|รายละเอียด|
|:-------:|-------------------------------------|
|15/ 2563 |[แก้ไขเพิ่มเติมประกาศกรมศุลกากรที่ 187/.2560](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&top_menu=menu_homepage&current_id=142328324149505f48464b4b464b4a)|
|286/.2562|[แก้ไขเพิ่มเติมประกาศกรมศุลกากรที่ 187/.2560](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=142328324149505f46464b4c464b49)|
|207/.2562|[แก้ไขเพิ่มเติมประกาศกรมศุลกากรที่ 303/.2562](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=142328324148505f48464a4e464b49)|
|114/.2562|[แก้ไขเพิ่มเติมประกาศกรมศุลกากร ที่ 187/.2560](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=142328324147505f49464b4d464b4c)|
|74/.2562|[แก้ไขเพิ่มเติมประกาศกรมศุลกากรที่ 187/.2560](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=142328324147505e4f464a4e464b47)|
|303/.2561|[แก้ไขเพิ่มเติมประกาศกรมศุลกากร ที่ 187/.2560](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=14232832404f505f4a464b4a464b4b)|
|187/.2560|[หลักเกณฑ์และพิธีการการยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=14223132414c505f46464a4f464b4c)|
|158/.2560|[หลักเกณฑ์และพิธีการการยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=14223132414b505f4b464b49464b46)|
|240/.2559|[หลักเกณฑ์และพิธีการการยกเว้นอากรและลดอัตราอากรศุลกากรสำหรับของที่มีถิ่นกำเนิดจากอาเซียน](http://www.customs.go.th/cont_strc_download_with_docno_date.php?lang=th&current_id=142231324149505f48464b4b464a4e)|

{{< /tab >}}
{{< tab "ประกาศสำนักพิกัดอัตราศุลกากร" >}}

#### ประกาศสำนักพิกัดอัตราศุลกากร

-   [ประกาศสำนักพิกัดอัตราศุลกากร ที่่ 8 / 2554 เรื่อง การยื่น Invoice Declaration จากประเทศบรูไน ดารูซาลาม มาเลเซีย และสิงคโปร์ เพื่อผ่านพิธีการศุลกากรในการใช้สิทธิพิเศษทางภาษีศุลกากรในระบบรับรองถิ่นกำเนิดสินค้าด้วยตนเองของอาเซียน โดยการวางประกัน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142231324147505f4c464b4c464b49)
-   [ประกาศสำนักพิกัดอัตราศุลกากร ที่ 2 / 2559 การระบุใน Form D กรณีการซื้อขายผ่านนายหน้าโดยนายหน้าและผู้ผลิตอยู่ในประเทศเดียวกัน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142231324148505e4f464b4a464b4c)
-   [ประกาศสำนักพิกัดอัตราศุลกากร ที่่ 1 / 2561เรื่อง การสะสมถิ่นกำเนิดสินค้าระหว่าง Form D กับโครงการนำร่องการรับรองถิ่นกำเนิดสินค้าด้วยตนเองของภูมิภาคโครงการที่ 1และโครงการที่ 2 ภายใต้ความตกลงการค้าสินค้าของอาเซียน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=14223132414c505f49464b47464b4a)
-   [ประกาศสำนักพิกัดอัตราศุลกากรที่ 3 / 2561 เรื่องการตีความคำว่า 'other quanity' ในช่องที่ 9 ของหนังสือรับรองถิ่นกำเนิดสินค้า (Form D) ภายใต้ความตกลงการค้าสินค้าของอาเซียน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=14223132414d505f46464a4f464b4b)
-   [ประกาศกองพิกัดอัตราศุลกากรที่ 10 / 2562 เรื่อง การใช้ Back-to-Back CO ควบคู่กับการใช้ใบกำกับราคาสินค้า Third Country invoicing ภายใต้ความตกลงการค้าสินค้าของอาเซียน](http://www.customs.go.th/cont_strc_download.php?lang=th&current_id=142328324148505f48464a4e464a4e)
{{< /tab >}}
{{< /tabs >}}

**Reference :** 

- [สถาบันพระปกเกล้า](http://wiki.kpi.ac.th/index.php?title=%E0%B9%80%E0%B8%82%E0%B8%95%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%84%E0%B9%89%E0%B8%B2%E0%B9%80%E0%B8%AA%E0%B8%A3%E0%B8%B5%E0%B8%AD%E0%B8%B2%E0%B9%80%E0%B8%8B%E0%B8%B5%E0%B8%A2%E0%B8%99)  
- [กรมศุลกากร](http://www.customs.go.th/cont_strc_simple_net_with_download.php?ini_content=usage_fta_and_wto_01_02&ini_menu=menu_interest_and_law_160421_01&left_menu=menu_fta_and_wto)