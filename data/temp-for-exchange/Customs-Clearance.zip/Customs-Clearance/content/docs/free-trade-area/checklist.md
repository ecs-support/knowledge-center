---
title: Checklist กฎว่าด้วยถิ่นกำเนิดสินค้า
bookCollapseSection: true
weight: 1
bookToc: false
---

ข้อพึงรู้พึงระวังเกี่ยวกับกฎว่าด้วยถิ่นกำเนิดสินค้า
===


![enter image description here](https://github.com/yosarawut/e-TaxIncentive/raw/master/img/origin-check-list-01.jpg)
![enter image description here](https://github.com/yosarawut/e-TaxIncentive/raw/master/img/origin-check-list-02.jpg)

ที่มา : [กรมศุลกากร](http://www.customs.go.th/list_strc_download.php?ini_content=fta_and_wto_160809_01_160809_04&ini_menu=menu_interest_and_law_160421_03&lang=th&root_left_menu=menu_interest_and_law_160421_03&left_menu=menu_interest_and_law_160421_03_160928_02)
วันที่ปรับปรุงข้อมูลล่าสุด :  11 กันยายน 2562

{{< hint info >}}
**สอบถามข้อมูลเพิ่มเติมได้ที่** : ส่วนกฎว่าด้วยถิ่นกำเนิดสินค้า (สกก.) กองพิกัดอัตราศุลกากร (กพก.)
กรมศุลกากร เลขที่ 1 ถ.สุนทรโกษา คลองเตย กทม. 10110
หมายเลขโทรศัพท์ : 0-2667-7014 หรือ 0-2667-6459
อีเมล์ : 80150000@customs.go.th
{{< /hint >}}