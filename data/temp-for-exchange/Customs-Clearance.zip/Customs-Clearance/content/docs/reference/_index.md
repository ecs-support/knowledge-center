---
title: ข้อมูลอ้างอิง 
bookCollapseSection: true
weight: 8
bookToc: false
---

ข้อมูลอ้างอิง (Reference)
===

![](https://www.careeraddict.com/uploads/article/53728/Reference_20word_20written_20on_20wood_20block_201.jpg)

{{< button relref="/docs/reference/exchange-rate">}}อัตราแลกเปลี่ยน{{< /button >}}
{{< button relref="/docs/reference/country">}}รหัสประเทศ{{< /button >}}
{{< button relref="/docs/reference/area">}}รหัสสถานที่{{< /button >}}
{{< button relref="/docs/reference/province">}}รหัสจังหวัด{{< /button >}}
{{< button relref="/docs/reference/unit">}}รหัสหน่วยสินค้า{{< /button >}}
{{< button relref="/docs/reference/package">}}ลักษณะหีบห่อ{{< /button >}}
{{< button relref="/docs/reference/cartype">}}รหัสประเภทรถ{{< /button >}}
{{< button relref="/docs/reference/exempt">}}รหัสยกเว้นไม่ต้องมีใบอนุญาต{{< /button >}}
{{< button relref="/docs/reference/container-code">}}ขนาดและประเภทตู้สินค้า{{< /button >}}


