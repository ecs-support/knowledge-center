---
title: การโอนย้ายของออกจากสิทธิประโยชน์
bookCollapseSection: true
weight: 7
bookToc: false
---

การโอนย้ายของออกจากสิทธิประโยชน์
===

-   [คลังสินค้าทัณฑ์บน](bond/)
-   [ขอคืนอากรตามมาตรา 29](section_29/)
-   [ส่งเสริมการลงทุน BOI](boi/)
-   [เขตปลอดอากร (Freezone)](freezone/)  
-   [เขตประกอบการเสรี (I-EAT)](i-eat/)