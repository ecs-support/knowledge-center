---
weight: 8
bookFlatSection: true
title: รูปแบบเลขที่ใบขนสินค้า
bookToc: false
---

รูปแบบเลขที่ใบขนสินค้า
===

![](https://github.com/ecs-support/knowledge-center/raw/master/img/export/export-guide/e-Export-guidejpg_Page49.jpg)